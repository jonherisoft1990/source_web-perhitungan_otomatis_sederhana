<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form>
		<table border="1" align="center">
			<tr>
				<td colspan="3" align="center"><h3>Perhitungan Otomatis</h3></td>
			</tr>
			<tr>
				<td>Harga Satuan</td>
				<td>:</td>
				<td><input type="number" name="harga_satuan" id="harga_satuan" onfocus="mulaiHitung()" onblur="berhentiHitung()"></td>
			</tr>
			<tr>
				<td>Jumlah Beli</td>
				<td>:</td>
				<td><input type="number" name="jumlah_beli" id="jumlah_beli" onfocus="mulaiHitung()" onblur="berhentiHitung()"></td>
			</tr>
			<tr>
				<td>Total Harga</td>
				<td>:</td>
				<td><input style="background-color: red;" type="number" name="total_harga" id="total_harga" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Diskon</td>
				<td>:</td>
				<td><input style="background-color: red;" type="text" name="diskon" id="diskon" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Total Harga Setelah Diskon</td>
				<td>:</td>
				<td><input style="background-color: red;" type="text" name="setelah_diskon" id="setelah_diskon" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Bayar</td>
				<td>:</td>
				<td><input type="text" name="bayar" id="bayar" onfocus="mulaiHitung()" onblur="berhentiHitung()"></td>
			</tr>
			<tr>
				<td>Kembalian</td>
				<td>:</td>
				<td><input style="background-color: red;" type="text" name="kembalian" id="kembalian" readonly="readonly"></td>
			</tr>
			<script type="text/javascript">
				function mulaiHitung(){
					Interval = setInterval("hitung()",1);
				}
				function hitung(){
					harga_satuan 	= parseInt(document.getElementById("harga_satuan").value);
					jlm_beli 		= parseInt(document.getElementById("jumlah_beli").value);
					total_harga 	= harga_satuan * jlm_beli;
					document.getElementById("total_harga").value = total_harga;
					
					//kita coba jika total harga lebih dari 100k, maka diskon 10%
					//10/100 --> adalah 10%
					//sekarang kita coba kreasikan
					//ok, semua sudah jalan.
					//sekarang kita kreasikan menggunakan pembayaran dan kembalian
					//lanjut....

					diskon="";
					persen="";
					if (total_harga < 100000){ //--> jika total harga dari kurang dari 100k
						diskon = (0/100) * total_harga; //--> maka diskon 0%
						persen = "0%";
					}
					else if (total_harga >= 100000 && total_harga < 200000){ //--> jika total harga dari 100k sampai (200K kurang 1)
						diskon = (10/100) * total_harga; //-->  maka diskon 10%
						persen = "10%";
					}
					else if (total_harga >= 200000 && total_harga < 300000){ //--> jika total harga lebih dari 200k sampai (300K kurang 1)
						diskon = (30/100) * total_harga; //-->  maka diskon 30%
						persen = "20%";
					}
					else if (total_harga >= 300000){ //--> jika total harga dari 300K lebih
						diskon = (40/100) * total_harga; //-->  maka diskon 40%
						persen = "30%";
					}
					//sekarang tampilkan ke textfield diskon
					document.getElementById("diskon").value = persen +" --> Rp. "+ diskon;
					setelah_diskon = total_harga - diskon; //ini adalah logika total harga setelah diskon
					document.getElementById("setelah_diskon").value = "Rp. "+ setelah_diskon;

					//kembalian = bayar - total_harga_seleah_diskon
					bayar 		= parseInt(document.getElementById("bayar").value);
					kembalian 	= bayar - setelah_diskon;
					document.getElementById("kembalian").value = "Rp. "+ kembalian;
					//karena field bayar adalah inputan, maka tambahkan onfocus dan onblur

					/*
					selanjutnya, logikanya seharusnya textfield otomatis tidak boleh diedit
					maka dari itu, tambahkan pada textfield-textfield yang otomatis koding readonly
					seperti berikut

					setelah anda tampahkan readonlu pada textfield yang otomatis, maka textfield tersebut tidak dapat diedit

					selanjunya silahkan anda berkreasi sesuai keinginan anda

					SELAMAT MENCOBA
					*/

				}
				function berhentiHitung(){
					clearInterval(Interval);
				}
			</script>
		</table>
	</form>
</body>
</html>